/*execute.c*/

//
// Project: Execution of queries for SimpleSQL
//
// YOUR NAME
// Northwestern University
// CS 211, Winter 2023
//

#include <stdbool.h> // true, false
#include <stdio.h>
#include <stdlib.h>
//
// #include any other system <.h> files?
//

#include "execute.h"
//
// #include any other of our ".h" files?
//


//
// implementation of function(s), both private and public
//
