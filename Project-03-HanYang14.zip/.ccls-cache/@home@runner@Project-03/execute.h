/*execute.h*/

//
// Project: Execution of queries for SimpleSQL
//
// YOUR NAME
// Northwestern University
// CS 211, Winter 2023
//

#pragma once

//
// #include header files needed to compile function declarations
//

//
// function declarations:
//
